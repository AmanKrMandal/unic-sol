import React from "react";
import { Link } from "react-router-dom";

const Notication = () => {
  return (
    <div>
      <div>home dnkjdfnhdb kjdsf</div>
      <Link to="/">
        <button className="btn btn-warning" type="button">
          Home Page
        </button>
      </Link>
    </div>
  );
};

export default Notication;
